"use strict";
cc._RF.push(module, '27d47X4cOVFMKhw7NP/+CTF', 'Player');
// scripts/Player.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseObject_1 = require("./BaseObject");
// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Player_1 = Player;
    Object.defineProperty(Player, "isLocalPlayer", {
        get: function () {
            return Player_1._isLocalPlayer;
        },
        set: function (value) {
            Player_1._isLocalPlayer = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Player.prototype, "score", {
        get: function () {
            return this._score;
        },
        set: function (value) {
            this._score = value;
        },
        enumerable: true,
        configurable: true
    });
    var Player_1;
    Player._isLocalPlayer = false;
    Player = Player_1 = __decorate([
        ccclass
    ], Player);
    return Player;
}(BaseObject_1.default));
exports.Player = Player;

cc._RF.pop();