"use strict";
cc._RF.push(module, '4acbc0j8EpGgYZmQIwnR//A', 'Leaderboard_item');
// scripts/Leaderboard_item.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.yourName = null;
        _this.yourScore = null;
        return _this;
    }
    NewClass.prototype.updateItem = function (name, score) {
        this.yourName.string = name;
        this.yourScore.string = score;
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "yourName", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "yourScore", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();