"use strict";
cc._RF.push(module, 'fb0e61/twBIgI/A5X5SCJxG', 'ResourceManager');
// scripts/ResourceManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ResourceManager = /** @class */ (function () {
    function ResourceManager() {
        this.playerSprites = [];
        this.eggSprites = [];
        this.isInited = false;
        this.TYPE_PLAYER = 0;
        this.TYPE_EGG = 1;
        this.MAX_SKIN_PLAYER = 8;
        this.MAX_SKIN_EGG = 7;
    }
    ResourceManager_1 = ResourceManager;
    ;
    ResourceManager.getInstance = function () {
        if (ResourceManager_1.instance == null) {
            ResourceManager_1.instance = new (ResourceManager_1);
        }
        return ResourceManager_1.instance;
    };
    ResourceManager.prototype.init = function () {
        console.log("Loading resource");
        var self = this;
        var _loop_1 = function (i) {
            var img_name = "textures/Players/player_0" + i;
            cc.loader.loadRes(img_name, cc.SpriteFrame, function (err, spriteFrame) {
                self.addSprite(self.TYPE_PLAYER, spriteFrame);
                if (i == self.MAX_SKIN_PLAYER - 1) {
                    console.log("Finish Init Player Sprite");
                }
            });
        };
        for (var i = 0; i < this.MAX_SKIN_PLAYER; i++) {
            _loop_1(i);
        }
        var _loop_2 = function (i) {
            var img_name = "textures/Eggs/egg_0" + i;
            cc.loader.loadRes(img_name, cc.SpriteFrame, function (err, spriteFrame) {
                self.addSprite(self.TYPE_EGG, spriteFrame);
                if (i == self.MAX_SKIN_EGG - 1) {
                    // self.initEggs();
                    console.log("Finish Init Egg Sprite");
                    self.isInited = true;
                }
            });
        };
        for (var i = 0; i < this.MAX_SKIN_EGG; i++) {
            _loop_2(i);
        }
    };
    ResourceManager.prototype.addSprite = function (type, sprite) {
        if (type == this.TYPE_PLAYER) {
            this.playerSprites.push(sprite);
        }
        if (type == this.TYPE_EGG) {
            this.eggSprites.push(sprite);
        }
    };
    ResourceManager.prototype.getSprite = function (type, index) {
        var sprite;
        if (type == this.TYPE_PLAYER) {
            sprite = this.playerSprites[index];
        }
        if (type == this.TYPE_EGG) {
            sprite = this.eggSprites[index];
        }
        return sprite;
    };
    ResourceManager.prototype.getSpriteList = function (type) {
        if (type == this.TYPE_PLAYER) {
            return this.playerSprites;
        }
        if (type == this.TYPE_EGG) {
            return this.eggSprites;
        }
    };
    var ResourceManager_1;
    ResourceManager = ResourceManager_1 = __decorate([
        ccclass
    ], ResourceManager);
    return ResourceManager;
}());
exports.ResourceManager = ResourceManager;

cc._RF.pop();