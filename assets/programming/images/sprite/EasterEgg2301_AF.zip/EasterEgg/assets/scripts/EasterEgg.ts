import { ResourceManager } from "./ResourceManager";
import { Server } from "./Server";

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property
    playerID:number = 0; // Local player, for remote player will be set > 0;

    @property(cc.Label)
    pName:cc.Label = null;

    pFrame = 0;
    MAX_EGG_SKINS = 8;
    MAX_SKIN_PLAYER = 8;
    @property(cc.Prefab)
    remotePlayer:cc.Prefab = null;

    remotePlayerList : any[];

    //Action Move direction
    action_move = 0;
    IDLE        = 0;
    MOVE_LEFT   = 1;
    MOVE_RIGHT  = 2;
    MOVE_UP     = 3;
    MOVE_DOWN   = 4;
    MOVE_COUNT   = 5;
    

    autoSaveInterval: number;
    myPos: cc.Vec2;

    // MAP_INFO
    F_COL = 0;
    F_ROW = 0;
    MAX_PLAYER = 0;
    MATCH_TIME = 0;
    //
    isLocalPlayer: boolean = false;

    initPosX:number = -515;
    initPosY:number = -275;
    cell_w: number = 50;   
    moveDistance = 100;

    //GAME STATE
    GAME_STATE_WAITING = 0;
    GAME_STATE_RUNING  = 1;
    GAME_STATE_OVERED  = 2;
    gamestate = 0;
    // COMMAND send between CLIENT and SERVER
   
    COMMAND_SEND_JOIN_REQUEST = 0;
    // MATCH_INFO : NUMPLAYER | MATCH_TIME | MAP COLUMNS | MAP ROWS
    COMMAND_SEND_MATCH_INFO = 1;    
    COMMAND_SEND_START_GAME = 2;
    COMMAND_SEND_WINNER = 3;
    COMMAND_SEND_PLAYER_POS = 4;
    COMMAND_SEND_COLLECTED_EGG = 5;
    COMMAND_SEND_UPDATE_SCORE = 6;
    COMMAND_SEND_INIT_PLAYERS_POS = 7;
    COMMAND_SEND_EGGS_POS = 8;
    COMMAND_SEND_UPDATE_PLAYERS_POS = 9;    

    //
    eggsPos: any[];
    playerPos: any[];
    remotePlayerPos: any[];
    scorelist: any[];

    lastTimeUpdate:any;
    playerSprite: any[];
    latencyTime: number;
    delayedTime: number;

    scaleRatioX = 0;
    scaleRatioY = 0;
    F_SIZE = 13;
    // LEADERBOARD

    onGameStart(time){
        this.gamestate = this.GAME_STATE_RUNING;
        //Start Countdown Timer for Client
        // this.node.parent.parent.getChildByName("ConnectingPop").active = false;
        // this.node.parent.parent.getChildByName("CountdownTimer").getComponent("TimerCountDown").startCountdownTimer(this.MATCH_TIME/1000);
    }
    // GAME STATE END
    getPositionXY(col, row){
        let pos = cc.v2(0,0);
        pos.x = this.initPosX +(this.cell_w * col);
        pos.y = this.initPosY +(this.cell_w * row);
        return pos;
    }   

    getPositionInField(x, y){
        // col/row should be in range 0 :-> F_COL/F_ROW
        let col = (x - this.initPosX)/this.cell_w;
        let row = (y - this.initPosY)/this.cell_w;
        if(col < 0) col = 0;
        if(row < 0) row = 0;
        return (cc.v2(col, row));
    }   

    onKeyUp(event) {
        // Reset Action when key up ANY KEY
        this.action_move = this.IDLE;
    },

    onKeyDown(event) {

        switch(event.keyCode)
        {
            
          case cc.macro.KEY.left:
          case cc.macro.KEY.a:
              this.action_move = this.MOVE_LEFT;
              break;
  
          case cc.macro.KEY.right:
          case cc.macro.KEY.d:
            this.action_move = this.MOVE_RIGHT;
              break;            
  
          case cc.macro.KEY.up:
          case cc.macro.KEY.w:
            this.action_move = this.MOVE_UP;
              break;            
  
          case cc.macro.KEY.down:
          case cc.macro.KEY.s:
            this.action_move = this.MOVE_DOWN;
              break;            
        }
        // console.log("action move for LocalPlayer "+ this.action_move);
        
    },


    moveToEgg(pos){
        // make a random, 
        let ranMove = [];
        let dis = 0.1; // make moving smooth

        if(this.myPos.x > pos.x + dis)
        {
            ranMove.push(this.MOVE_LEFT);
        }
        else if(this.myPos.x <pos.x - dis) 
        {   
            ranMove.push(this.MOVE_RIGHT);
        }

        if(this.myPos.y > pos.y + dis)
        {
            ranMove.push(this.MOVE_DOWN);
        }
        else if(this.myPos.y <pos.y -dis) 
        {   
            ranMove.push(this.MOVE_UP);
        }
        
        this.action_move = ranMove[Math.floor(Math.random()* ranMove.length)];
    }

    moveActionToNearEgg(){
        if(1) return;

        // if(this.gamestate !=this.GAME_STATE_RUNING || this.eggsPos == null || this.eggsPos.length == 0)
        // {
        //     return;
        // }
        //find index of the egg nearest 
        var minIndex = 0 ;
        var minDist  = this.myPos.sub(this.eggsPos[0]).mag();
        for(let i = 1; i < this.eggsPos.length ; i++)
        {
           let distance = this.myPos.sub(this.eggsPos[i]).mag();
           if(minDist >  distance)
           {
               minDist = distance;
               minIndex = i;
           }
           
        }
        // movo to it 
        this.moveToEgg (this.eggsPos[minIndex]);
    }

    AI_Action(){
    //    this.moveActionToNearEgg();
        this.action_move =Math.floor( Math.random() * this.MOVE_COUNT);
    },

    
    initRemotePlayers(numRemotePlayer){
        // console.log("initRemotePlayers "+numRemotePlayer);
        for(let i = 0; i < numRemotePlayer; i++){
            var remote = cc.instantiate(this.remotePlayer);
            remote.getComponent(cc.Sprite).spriteFrame =this.playerSprite[i+1];
            // console.log("Set spriteframe for remote player "+i);
            this.remotePlayerList.push(remote);

            // console.log("remotePlayerList "+ this.remotePlayerList);
            // console.log("remotePlayerPos "+ this.remotePlayerPos);

            this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))   
            
            // this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))   
               
            this.node.parent.addChild(remote);
        }
    }
    
            
    clientSendCollectedEgg(eID){
        // let pos = this.getPositionInField(posEggCollected.x, posEggCollected.y)
        let data = "";
        data += String.fromCharCode(this.COMMAND_SEND_COLLECTED_EGG);
        // data += String.fromCharCode(this.playerID);
        data += String.fromCharCode(eID);
        console.log("Player ID "+this.playerID + "send Collected "+eID);
        
        this.clientSendMessage(data);
        
    }

    clientUpdateRemotePlayerPos() {
        if(this.remotePlayerList == null || this.remotePlayerList.length != (this.MAX_PLAYER -1 ) || this.remotePlayerPos.length != (this.MAX_PLAYER - 1))
            return;
        // let isResolvedLatency = this.node.parent.getChildByName("Latency_Compensation").getComponent(cc.Toggle).isChecked;
        let isResolvedLatency =  this.node.parent.parent.getChildByName("Latency_Compensation").getComponent(cc.Toggle).isChecked;
        for (let i = 0 ; i < this.MAX_PLAYER - 1; i ++){
            if(!isResolvedLatency){
                this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))
            }
            else{
                let currenPlayerPos = cc.v2(this.remotePlayerList[i].x, this.remotePlayerList[i].y);
                let remotePlayerPosXY = this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y);
                let lagDistance:cc.Vec2 = remotePlayerPosXY.sub(currenPlayerPos);
                // the largest dis we can apply
                if(lagDistance.mag() < 5 )
                {
                    this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))
                }
                else
                {
                    let x = lagDistance.normalize().x;
                    let y =  lagDistance.normalize().y;

                    let newMove = cc.v2(x,y).mul(1.6);
                    this.remotePlayerList[i].setPosition(currenPlayerPos.x + newMove.x, currenPlayerPos.y + newMove.y));
                }
            }
        }
    }

    clientSendPos(){
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_PLAYER_POS);
        data += String.fromCharCode(this.myPos.x * 100);
        data += String.fromCharCode(this.myPos.y * 100);
        
        this.clientSendMessage(data);
    }
    
    clientSendMessage(data){
        // if (1) return;
        let newData = "";
        // Insert PlayerID at index 0
        newData     += String.fromCharCode(this.playerID);
        newData     += data;
        Server.getInstance().send(newData);
    }
    // END OF COMUNICATION
    start () {
    }

    onLoad(){
        this.playerSprite = [];
        this.remotePlayerList = [];
        // this.gamestate = this.GAME_STATE_WAITING;        
        console.log("Player ID : "+this.playerID + " is Local Player :"this.isLocalPlayer);
        
        if(this.isLocalPlayer){
            // this.loadPlayers();
            // this.playerSprite = ResourceManager.getInstance().getSpriteList(ResourceManager.getInstance().TYPE_PLAYER);
            cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP,  this.onKeyUp, this);
            cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN,  this.onKeyDown, this);
        }
        else{
             this.pName.string = "p" +this.playerID;
        }
    }

    update (dt) {
        // Update and send new Pos to server
        if (!this.isLocalPlayer)
        {
            this.AI_Action();    
        }
        else
        {
            this.clientUpdateRemotePlayerPos(); 
        }
        // if( this.action_move == this.IDLE) 
        // if(this.gamestate != this.GAME_STATE_RUNING || this.action_move == this.IDLE) 
            // return;
        // console.log("Update "+this.action_move);
            
        let currentPos =  this.getPositionInField(this.node.x, this.node.y);
        // if (this.isLocalPlayer)
        //     console.log(currentPos);
        if (this.action_move == this.MOVE_LEFT && currentPos.x > 0)
        {
            // console.log("Update MOVE LEFT");
            this.node.x -= this.moveDistance * dt;

        }
        if (this.action_move == this.MOVE_RIGHT && currentPos.x < this.F_SIZE - 1)
        {
            this.node.x += this.moveDistance * dt;
            // console.log("Update MOVE MOVE_RIGHT");
        }
        if (this.action_move == this.MOVE_UP && currentPos.y < this.F_SIZE - 1)
        {
            this.node.y += this.moveDistance * dt;
            // console.log("Update MOVE MOVE_UP");
        }
        if (this.action_move == this.MOVE_DOWN && currentPos.y > 0)
        {
            this.node.y -= this.moveDistance * dt;
            // console.log("Update MOVE MOVE_DOWN");
        }
        this.myPos = this.getPositionInField(this.node.x, this.node.y);
        this.clientSendPos();
    },
    
}
