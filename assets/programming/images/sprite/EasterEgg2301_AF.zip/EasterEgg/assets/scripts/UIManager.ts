import { UI } from "./UI";

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;
import { UI } from './UI';
@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    timerLabel:cc.Label = null;

    @property(cc.Label)
    leaderboard:cc.Label = null;
    @property(cc.Layout)
    connectionLayout:cc.Layout = null;    

    @property(cc.Prefab)
    lbItem:cc.Prefab = null;
    lb_list: [];

    matchTime: any;
    endTime: any;
    isGameStart: boolean;
    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        UI.getInstance().setUIManagerCallback(this);
        this.isGameStart = false;
        this.timerLabel.node.color = new cc.color(255, 255, 255, 0); 
        this.lb_list = [];
    }

    start () {

    }
    initCountdownTimer(time)
    {
        this.matchTime = time;
        this.timerLabel.string = this.convertNumberToTimer(time);

    }
    convertNumberToTimer(num)
    {
        let minute= Math.floor(num/60);
        let second = Math.floor((num - (minute * 60  )));
        let timer = this.formatTimer(minute, second);
        return timer;
    }    
    formatTimer(minute, second){
        let tmpString = '';
        if(minute < 10)
            tmpString += '0' + minute;
        else   
            tmpString += '' + minute;     
                     
        if(second < 10)
            tmpString += ':0' + second;
        else   
            tmpString += ':' + second;              
        return tmpString;
    
    },  
    startCountdownTimer(time){
        this.isGameStart = true;
        this.endTime = Date.now() + this.matchTime*1000; 
    }      

    displayTimer() {
        // timer in seconds
        let timer = (this.endTime - Date.now())/1000;
        //set highlight color
        if(timer < 10)  // alarm for user with Red color on timer
            this.timerLabel.node.color = new cc.color(255, 0, 0, 0);
        if(timer < 0){
            return;
        }

        let minute= Math.floor(timer/60);
        let second = Math.floor((timer - (minute * 60  )));
       
        this.timerLabel.string = this.convertNumberToTimer(timer);
       
    }

    hideConnection(){
        this.connectionLayout.node.active = false;
    }

    initLeaderBoard(num){
        var pos = 0;
        for (let i= 0; i < num; i++){
            let lb = cc.instantiate(this.lbItem);
            lb.getComponent("Leaderboard_item").updateItem("Player "+i, 0);
            lb.setPosition(0, pos);
            pos -= 60;
            this.leaderboard.node.addChild(lb);
            this.lb_list.push(lb);
        }
    }
    updateLeaderBoard(scores){
        for(let i = 0; i < scores.length; i++){
            this.lb_list[i].getComponent("Leaderboard_item").updateItem("Player "+i, scores[i]);
      }
    }
    update (dt) {
        if (this.isGameStart)
            this.displayTimer();
    }
}
