// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export class Server {
    
    private static _instance Server = null;
    classCallback: any;
    classClientCallback: any;
   
    callbackReceive: any;
    callbackSend: any;
    
    public static getInstance(){
        if(Server._instance == null){
            Server._instance = new (Server);

        }
        return Server._instance;

    }
    // setCallback(_class){
    //     console.log("Server SingleTon setCallback");
    //     console.log("Server SingleTon setCallback "+_class);
    //     this.classCallback = _class;
    // }

    // setClientCallback(_class){
    //     console.log("Client SingleTon setCallback");
    //     console.log("Client SingleTon setCallback "+_class);
    //     this.classClientCallback = _class;
    // }

    // onClientSendData(data){
    //     console.log("Server SingleTon onClientsendData");
        
    //     this.classCallback.onClientSendData(data);
    // }
    // onServerSendData(data){
    //     console.log("Server SingleTon onServerSendData");
    //     this.classClientCallback.onServerSendData(data);
    // }

    setCallbackReceive(func)
    {
        this.callbackReceive = func;
    }

    receive(data){
        this.callbackReceive(data);
    }


    setCallbackSend(func)
    {
        this.callbackSend = func;
    }

    send(data){
        this.callbackSend(data);
    }    

}
