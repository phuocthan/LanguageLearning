// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    winScore: cc.Label = null;

    @property(cc.Label)
    winName: cc.Label = null;

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        let name = cc.sys.localStorage.getItem("name");
        let score = cc.sys.localStorage.getItem("score");
        this.updateWinnerInfo(name, score);
    }
    updateWinnerInfo(name, score)
    {
        this.winName.string =  "Player " +name;
        this.winScore.string = "Score:"+score;
    }
    start () {

    }

    // update (dt) {}
}
