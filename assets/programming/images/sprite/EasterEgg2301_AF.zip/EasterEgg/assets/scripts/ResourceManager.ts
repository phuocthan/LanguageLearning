const {ccclass, property} = cc._decorator;

@ccclass
export class ResourceManager{

    public static instance: ResourceManager;
    private constructor () {};

    
    public static getInstance(){
        if(ResourceManager.instance == null){
            ResourceManager.instance = new (ResourceManager);

        }
        return ResourceManager.instance;

    }

    playerSprites : any = [];
    eggSprites : any = [];
    isInited = false;
    TYPE_PLAYER = 0;
    TYPE_EGG = 1;

    MAX_SKIN_PLAYER = 8;
    MAX_SKIN_EGG = 7;

    init(){
        console.log("Loading resource");
        var self = this;
        for(let i = 0; i < this.MAX_SKIN_PLAYER ; i++){
            let img_name = "textures/Players/player_0" + i;
        
            cc.loader.loadRes(img_name, cc.SpriteFrame, function(err,spriteFrame){
                
                 self.addSprite(self.TYPE_PLAYER, spriteFrame)
                 if(i == self.MAX_SKIN_PLAYER - 1) 
                 {
                    console.log("Finish Init Player Sprite");
                 }  
            })
        }
        for(let i = 0; i < this.MAX_SKIN_EGG ; i++){
            let img_name = "textures/Eggs/egg_0" + i;
        
            cc.loader.loadRes(img_name, cc.SpriteFrame, function(err,spriteFrame){
                
                self.addSprite(self.TYPE_EGG, spriteFrame)
                 if(i == self.MAX_SKIN_EGG-1 ) 
                 {
                    // self.initEggs();
                    console.log("Finish Init Egg Sprite");
                    self.isInited = true;
                 }  
            })
        }       
    }
    addSprite (type, sprite){

        if (type == this.TYPE_PLAYER){
            this.playerSprites.push(sprite);
        }
        
        if (type == this.TYPE_EGG){
            this.eggSprites.push(sprite);
        }
    }

    getSprite(type, index){
        let sprite : cc.Sprite;
        if (type == this.TYPE_PLAYER){
            sprite = this.playerSprites[index];
        }
        if (type == this.TYPE_EGG){
            sprite = this.eggSprites[index];
        }
        return sprite;
    }

    getSpriteList(type){
        if (type == this.TYPE_PLAYER){
            return this.playerSprites;
        }
        if (type == this.TYPE_EGG){
            return this.eggSprites;
        }
    }    
}
