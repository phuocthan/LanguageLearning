import { ResourceManager } from "./ResourceManager";

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;
import {Player} from './Player';
import {Egg} from './Egg';
import { Server } from "./Server";

@ccclass
export  class ServerManager extends cc.Component {

	// Max Player 
    @property
    MAX_PLAYER:number = 0;   
	
    MAX_SKIN_PLAYER:number = 8;


    @property
    MAX_EGG:number = 0;

    MAX_SKIN_EGG:number = 7;

    @property(cc.Prefab)
    players:cc.Prefab = null;
    
    @property(cc.Prefab)
    eggs:cc.Prefab = null;

    @property(cc.Prefab)
    cell: cc.Prefab = null;    

    @property(cc.Toggle)
    latencyToggle:cc.Toggle = null;

    @property(cc.Toggle)
    showRemoteToggle:cc.Toggle = null;

    // define for num columns and rows will have in the battle field/
    // @property
    F_SIZE: number = 13;
    
    //
    initPosX:number = -515;
    initPosY:number = -275;
    cell_w: number = 50;
    eggSprite: any[];
    field: any[];
    playerSprite: any[];
    // MATCH_TIME : TIME FOR EACH MATCH , UPDATE_TIME : SERVER WILL SEND STAGE INFO TO ALL PLAYER , WAITING_TIME: TIME BEFORE START GAME
    @property
    MATCH_TIME = 20 * 1000;
    UPDATE_TIME = 20;
    WAITING_TIME = 3 * 1000;
    listPlayer: any[];

    listScore: any[];
    eggsPos: cc.Vec2[];
    playerPos: cc.Vec2[];
    eggsList: any[];
    updateInterval: number;

    //CELL INFO, = 0 - EMPTY, 1 - PLAYER , 2 - EGG.
    CELL_EMPTY = 0;
    CELL_PLAYER = 1;
    CELL_EGG = 2;
    // COMMAND send between CLIENT and SERVER
   
    COMMAND_SEND_JOIN_REQUEST = 0; // not deploy yet
    // MATCH_INFO : NUMPLAYER | MATCH_TIME | MAP COLUMNS | MAP ROWS
    COMMAND_SEND_MATCH_INFO = 1;    
    COMMAND_SEND_START_GAME = 2;
    COMMAND_SEND_WINNER = 3;
    COMMAND_SEND_PLAYER_POS = 4;
    COMMAND_SEND_COLLECTED_EGG = 5;
    COMMAND_SEND_UPDATE_SCORE = 6;
    COMMAND_SEND_INIT_PLAYERS_POS = 7;
    COMMAND_SEND_EGGS_POS = 8;
    COMMAND_SEND_UPDATE_PLAYERS_POS = 9;    
    // 
    isLatencies: false;
    

    LOADING_RESOURCE = 0;

    gameState = this.LOADING_RESOURCE;
    eggCount = 0;

    playerServer: any[];
    eggServer: any[];
    // resource: ResourceManager;
    startGame(){

        // COUNTDOWN TO GAME START
        this.startGameInterval = setTimeout(function(){

           this.serverSendStartGame();

        }.bind(this), this.WAITING_TIME);
    }

    sendMatchInfo(){
        // Server send message COMMAND_SEND_MATCH_INFO
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_MATCH_INFO);
        // // data += String.fromCharCode(this.MAX_PLAYER);
        data += String.fromCharCode(this.MATCH_TIME);
        // // data += String.fromCharCode(this.F_SIZE);
        // // data += String.fromCharCode(this.F_SIZE);
        // console.log("Server Send MAtch Info "+this.MATCH_TIME);

        // data += (this.COMMAND_SEND_MATCH_INFO).toString();
        // data += (this.MATCH_TIME).toString();
            // console.log("Server Send MAtch Info "+data);
        this.serverSendMessage(data);
            // console.log("Server Send MAtch Info "+this.MATCH_TIME);
    }

    serverSendEggsPos(){
        let data = "";
        data += String.fromCharCode(this.COMMAND_SEND_EGGS_POS);
        data += String.fromCharCode(this.eggServer.length);
        for (let i =0 ; i < this.eggServer.length ; i++)
        {
            let egg = this.eggServer[i];
            // data += String.fromCharCode(pos.x);
            //egg ID
            data += String.fromCharCode(egg.id);
            //egg Skin
            data += String.fromCharCode(egg.skinId);
            //eggPos
            let pos:cc.Vec2 = this.eggServer[i].position;            
            data += String.fromCharCode(pos.x);
            data += String.fromCharCode(pos.y);
        }
        this.serverSendMessage(data);
    }
    GameOver(){

        console.log("GameOVer END TIME");
        clearInterval(this.updateInterval);
        let winnerID = this.getWinner();
        let winnerScore = this.playerServer[winnerID].score;
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_WINNER);
        data += String.fromCharCode(winnerID);
        data += String.fromCharCode(winnerScore);

        console.log("WINNER : "+winnerID);
        console.log("SCORE : "+winnerScore);
         // Send message COMMAND_SEND_WINNER
        this.serverSendMessage(data);

    }

    serverSendMessage(data){
        // Send to all client
        // let command = data[0].charCodeAt(0);

        // // Make random latency for local player
        // for (let idx = 0; idx < this.MAX_PLAYER; idx++) {

        //    let player = this.listPlayer[idx];
        //    if(idx == 0 && this.latencyToggle.isChecked && command == this.COMMAND_SEND_UPDATE_PLAYERS_POS) // Make latency for Local Player Only when Toogle is checked
        //    {
        //         if (!this.isLatencies)
        //         {
        //             let latencies_time = Math.floor(Math.random() * 400);
        //             this.isLatencies = true;
        //             let latencies_timeout = setTimeout(function(){
        //                 player.getComponent("EasterEgg").onServerSendData(data);
        //                 this.isLatencies = false;
        //                 }.bind(this), latencies_time);
        //         }
        //         // else   
        //         // {
        //         //     // console.log("in Latencyyyyyyyyyyyyyyyyyyy");
        //         // } 
        //    }
        //    else
        //     player.getComponent("EasterEgg").onServerSendData(data);


            Server.getInstance().receive(data);
        // }
    }

    // onClientSendData(data){
    //     console.log("Server Manager onClientsendData");
    //     let i = 0;
    //     // PlayerID at index 0
    //     let pID = data[i++].charCodeAt(0);
    //      // command at index 1
    //     let command = data[i++].charCodeAt(0);
    //     // console.log(this.playerPos);
        
    //     switch(command)
    //     {
    //         case this.COMMAND_SEND_PLAYER_POS:
    //             let pX = data[i++].charCodeAt(0) / 100;
    //             let pY = data[i++].charCodeAt(0) / 100;
    //             this.playerPos[pID] = cc.v2(pX, pY);
    //             break;
    //         case this.COMMAND_SEND_COLLECTED_EGG:

    //             let eID = data[i++].charCodeAt(0);
    //             // let eY = data[i++].charCodeAt(0);
    //             console.log("Server get info User "+pID+" collected "+eID);
                
    //             this.gainScore(pID,eID)
    //     }
        
    // }
    onSend(data){
        // console.log("Game Send data for Server");
        let i = 0;
        // PlayerID at index 0
        let pID = data[i++].charCodeAt(0);
         // command at index 1
        let command = data[i++].charCodeAt(0);
        // console.log(this.playerPos);
        
        switch(command)
        {
            case this.COMMAND_SEND_PLAYER_POS:
                // let pos : cc.Vec2;
                let x = data[i++].charCodeAt(0) / 100;
                let y = data[i++].charCodeAt(0) / 100;
                let pos = cc.v2(x, y);
                this.playerServer[pID].position = pos;
                // console.log("Server get info User "+pID+" updated Pos "+pos);
                break;
            case this.COMMAND_SEND_COLLECTED_EGG:

                let eID = data[i++].charCodeAt(0);
                // let eY = data[i++].charCodeAt(0);
                // console.log("Server get info User "+pID+" collected "+eID);
                
                this.gainScore(pID,eID)
        }
        
    }

    onLoad () {
        // console.log("Loggggg");
        // console.log("Server Manager setCallback");
        // Server.getInstance().setCallback(this);

        Server.getInstance().setCallbackSend(this.onSend.bind(this));
        this.eggSprite = [];
        this.playerSprite = [];
        this.listPlayer = [];
        this.listScore = [];
        this.eggsList = [];
        this.eggsPos = [];
        this.playerPos = [];

        this.playerServer = [];
        this.eggServer = [];
        this.initField();
        // this.resource = ResourceManager.getInstance();
        // ResourceManager.getInstance().init();
        // this.startGameInterval = setTimeout(function(){

        // //     // this.serverSendStartGame();
        //     this.loadPlayers();
        //     this.loadEggs();
 
        //     this.startGame();
        //  }.bind(this), 1000);
        this.gameState = this.LOADING_RESOURCE;
        // load resource and init player/egg
        // this.loadPlayers();
        // this.loadEggs();

        // this.startGame();
        
    },

    getPositionXY(col, row){
        let pos = cc.v2(0,0);
        pos.x = this.initPosX +(this.cell_w * col);
        pos.y = this.initPosY +(this.cell_w * row);
        return pos;
    }    

    initField(){
        this.field = [];
        for(var i = 0; i < this.F_SIZE; i++) {
            this.field[i] = [];
            for(var j = 0; j < this.F_SIZE; j++){
                this.field[i][j]= this.CELL_EMPTY; 
            }
        }
    },

    gainScore(pID, eID){

        let indexEgg = this.getIndexEgg(eID);
        // Check if that egg already collected by other Player
        if(indexEgg >= 0)
        {
            console.log("Collected Egg "+eID + "is OK");
            
            let player = this.playerServer[pID];
            player.score += 1;

            // this.listScore[ID] += 1;
            this.eggServer.splice(indexEgg, 1);
            // RESET this cell on field as EMPTY
            // this.field[posE.x][posE.y] = this.CELL_EMPTY; 
            
            // let egg = this.eggsList[indexEgg];
            // egg.destroy();
            // this.eggsList.splice(indexEgg, 1);
            
            this.serverSendUpdateScore();
            this.spawnEgg();
            console.log(this.playerServer[pID].score);
            
            
        }
    }
    serverSendUpdateScore()
    {
        let data = "";
        data += String.fromCharCode(this.COMMAND_SEND_UPDATE_SCORE);
        for (let i = 0; i < this.playerServer.length; i++) {
            // let player = this.playerServer[i];
            data += String.fromCharCode(this.playerServer[i].score);
        }
       // Send client COMMAND_SEND_UPDATE_SCORE
        this.serverSendMessage(data);
    }

    serverSendUpdatePlayersPos(){
        let data ="";
        data += String.fromCharCode(this.COMMAND_SEND_UPDATE_PLAYERS_POS);
        for (let i = 0; i < this.playerServer.length; i++) {
            let player = this.playerServer[i];
            // data += String.fromCharCode(player.id);
            let pos = player.position;
            // let rand = Math.random() * this.F_SIZE;
            // if(i != 0)
            //    pos = cc.v2(pos.x + rand, pos.y +rand);
            data += String.fromCharCode(pos.x * 100);
            data += String.fromCharCode(pos.y * 100);
            // console.log("Player ");
            
        }
         // Send client COMMAND_SEND_UPDATE_PLAYERS_POS
         this.serverSendMessage(data);
    }

    // WINNER info : ID and Score
    // getIndex(element, )
    getWinner(){
        let maxScore = Math.max(...this.playerServer.map(o => o.score),0);
        // let index = this.playerServer.indexOf(Math.max(...this.listScore));
    //    console.log("Winer score "+this.playerServer[index].score);
    //    console.log("Winer Id "+this.playerServer[index].id);
        let index = this.playerServer.findIndex(o => o.score === maxScore);
        // console.log("Winer Id "+index);
        // console.log("Winer Id maxScore "+maxScore);
        // console.log("Winer PlayerID "+(this.playerServer[index].id));
        return index;
       
    }
    spawnEgg(){
        if(this.eggServer.length == this.MAX_EGG)
            return;

        var egg = new (Egg);
        var OK = false;
        // console.log("EGgsprite "+this.eggSprite);
        
        while (!OK)
        {
            var ranCol = Math.floor(Math.random() * this.F_SIZE);
            var ranRow = Math.floor(Math.random() * this.F_SIZE);
            if(this.field[ranCol][ranRow] == this.CELL_EMPTY) 
            {
                // egg.setPosition(this.getPositionXY(ranCol, ranRow));
                egg.position = cc.v2(ranCol, ranRow);
                // random color egg
                let ranSkinID = Math.floor(Math.random() * this.MAX_SKIN_EGG);
                egg.skinId = ranSkinID;
                egg.id = this.eggCount;
                // egg.getComponent(cc.Sprite).spriteFrame =this.eggSprite[ranEgg];
                // console.log("EGgsprite "+this.eggSprite[ranEgg]);
                // this.node.addChild(egg);
                // notice this field already have egg for the next check time
                this.field[ranCol][ranRow] = this.CELL_EGG;
                // this.eggsList.push(egg);
                // this.eggsPos.push(cc.v2(ranCol, ranRow));
                this.eggServer.push(egg);
                // this.eggsPos[0] = cc.v2(ranCol, ranRow);
                OK = true;
                this.eggCount += 1;
                
            }
        }
    }
    getIndexEgg(eID)
    {
        for (let i = 0; i < this.eggServer.length; i++)
        {
            let egg = this.eggServer[i];
           if(egg.id = eID) return i;
        }
        return -1;
    }
    initEggs(){
        var countEgg = 0;
        for(let i = 0; i < this.MAX_EGG ; i++){
            this.spawnEgg();
         }
        this.serverSendEggsPos();
         
    }    
    initPlayers(){
        for(let i = 0; i < this.MAX_PLAYER ; i++){
            var OK = false;
            while (!OK)
            {
                let _player = new (Player);
                var ranCol = Math.floor(Math.random() * this.F_SIZE);
                var ranRow = Math.floor(Math.random() * this.F_SIZE);
                if(this.field[ranCol][ranRow] == 0) // no egg/player in this cell
                {
                    // // _player.
                    // if(i == 0) player.zIndex = 1;  // keep local player alway on top
                    // else player.zIndex = -2;
                    // // this.node.addChild(player);

                    // this.listPlayer[i] = player;
                    // // init user score
                    // this.listScore[i] = 0; 
                    // // notice this cell on field already have player for the next check time
                    this.field[ranCol][ranRow] = this.CELL_PLAYER;
                
                    _player.id = i;
                    _player.position = cc.v2(ranCol, ranRow);
                    _player.skinId = i;
                    _player.score = 0;
                    this.playerServer.push(_player);

                    OK = true;
                    // console.log("Server Init Player "+this.playerServer);
                    
                }
            }
         }

    }
    sendInitPlayersPos(){
        let data = "";
        
        data += String.fromCharCode(this.COMMAND_SEND_INIT_PLAYERS_POS);
        for(let i = 0; i < this.playerServer.length ; i++){
            // console.log("Server send Pos for Player "+i + "pos : "+this.playerPos[i]);
            // let player = this.playerServer[i];
            let pos = this.playerServer[i].position;
            data += String.fromCharCode(pos.x);
             data += String.fromCharCode(pos.y);
             console.log("Send innit player pos player "+i + " pos: "pos);
             
        }
        this.serverSendMessage(data);
    }
    loadEggs(){
        // let resource = ResourceManager.getInstance();
        // this.eggSprite = resource.getSpriteList(resource.TYPE_EGG);
        this.initEggs();

    },
    loadPlayers(){
        let resource = ResourceManager.getInstance();

        this.playerSprite = resource.getSpriteList(resource.TYPE_PLAYER);
        // console.log(this.playerSprite);

        this.initPlayers();
        this.sendMatchInfo();
        // this.sendInitPlayersPos();
        //delay send pos
       let delayInit = setTimeout(function(){

            this.sendInitPlayersPos()

      }.bind(this), this.1000);
    },
   
    serverSendStartGame(){
        // TimeOut to GAME OVER 
        this.gameOverInterval = setTimeout(function(){

            this.GameOver()

      }.bind(this), this.MATCH_TIME);

        // Interval update, server send stage info
        this.updateInterval = setInterval(function(){

            // this.serverSendEggsPos();
            this.serverSendUpdatePlayersPos();

        }.bind(this), this.UPDATE_TIME);

        console.log("START GAME");
        // Send message COMMAND_SEND_START_GAME
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_START_GAME);
        data += String.fromCharCode(this.MATCH_TIME/1000);
        this.serverSendMessage(data);
    },
    update (dt) {
        if (this.gameState == this.LOADING_RESOURCE && ResourceManager.getInstance().isInited)
        {
            console.log("Finished Load Resource");
			this.loadPlayers();
			this.loadEggs();
			this.startGame();
			this.gameState = 3;
        }

        if(this.listPlayer.length < this.MAX_PLAYER ) return;
        for( let i = 1 ; i < this.MAX_PLAYER ; i ++){
            let player = this.listPlayer[i];
            if (this.showRemoteToggle.isChecked) {
                player.zIndex = 0;
            }
            else{
                player.zIndex = -2;
            }
        }
    }
}
