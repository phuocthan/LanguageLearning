(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/ServerManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '23c24DA7x5FF5rs8k90CrDW', 'ServerManager', __filename);
// scripts/ServerManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ResourceManager_1 = require("./ResourceManager");
// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player_1 = require("./Player");
var Egg_1 = require("./Egg");
var Server_1 = require("./Server");
var ServerManager = /** @class */ (function (_super) {
    __extends(ServerManager, _super);
    function ServerManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // Max Player 
        _this.MAX_PLAYER = 0;
        _this.MAX_SKIN_PLAYER = 8;
        _this.MAX_EGG = 0;
        _this.MAX_SKIN_EGG = 7;
        _this.players = null;
        _this.eggs = null;
        _this.cell = null;
        _this.latencyToggle = null;
        _this.showRemoteToggle = null;
        // define for num columns and rows will have in the battle field/
        // @property
        _this.F_SIZE = 13;
        //
        _this.initPosX = -515;
        _this.initPosY = -275;
        _this.cell_w = 50;
        // MATCH_TIME : TIME FOR EACH MATCH , UPDATE_TIME : SERVER WILL SEND STAGE INFO TO ALL PLAYER , WAITING_TIME: TIME BEFORE START GAME
        _this.MATCH_TIME = 20 * 1000;
        _this.UPDATE_TIME = 20;
        _this.WAITING_TIME = 3 * 1000;
        //CELL INFO, = 0 - EMPTY, 1 - PLAYER , 2 - EGG.
        _this.CELL_EMPTY = 0;
        _this.CELL_PLAYER = 1;
        _this.CELL_EGG = 2;
        // COMMAND send between CLIENT and SERVER
        _this.COMMAND_SEND_JOIN_REQUEST = 0; // not deploy yet
        // MATCH_INFO : NUMPLAYER | MATCH_TIME | MAP COLUMNS | MAP ROWS
        _this.COMMAND_SEND_MATCH_INFO = 1;
        _this.COMMAND_SEND_START_GAME = 2;
        _this.COMMAND_SEND_WINNER = 3;
        _this.COMMAND_SEND_PLAYER_POS = 4;
        _this.COMMAND_SEND_COLLECTED_EGG = 5;
        _this.COMMAND_SEND_UPDATE_SCORE = 6;
        _this.COMMAND_SEND_INIT_PLAYERS_POS = 7;
        _this.COMMAND_SEND_EGGS_POS = 8;
        _this.COMMAND_SEND_UPDATE_PLAYERS_POS = 9;
        _this.LOADING_RESOURCE = 0;
        _this.gameState = _this.LOADING_RESOURCE;
        _this.eggCount = 0;
        return _this;
    }
    // resource: ResourceManager;
    ServerManager.prototype.startGame = function () {
        // COUNTDOWN TO GAME START
        this.startGameInterval = setTimeout(function () {
            this.serverSendStartGame();
        }.bind(this), this.WAITING_TIME);
    };
    ServerManager.prototype.sendMatchInfo = function () {
        // Server send message COMMAND_SEND_MATCH_INFO
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_MATCH_INFO);
        // // data += String.fromCharCode(this.MAX_PLAYER);
        data += String.fromCharCode(this.MATCH_TIME);
        // // data += String.fromCharCode(this.F_SIZE);
        // // data += String.fromCharCode(this.F_SIZE);
        // console.log("Server Send MAtch Info "+this.MATCH_TIME);
        // data += (this.COMMAND_SEND_MATCH_INFO).toString();
        // data += (this.MATCH_TIME).toString();
        // console.log("Server Send MAtch Info "+data);
        this.serverSendMessage(data);
        // console.log("Server Send MAtch Info "+this.MATCH_TIME);
    };
    ServerManager.prototype.serverSendEggsPos = function () {
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_EGGS_POS);
        data += String.fromCharCode(this.eggServer.length);
        for (var i = 0; i < this.eggServer.length; i++) {
            var egg = this.eggServer[i];
            // data += String.fromCharCode(pos.x);
            //egg ID
            data += String.fromCharCode(egg.id);
            //egg Skin
            data += String.fromCharCode(egg.skinId);
            //eggPos
            var pos = this.eggServer[i].position;
            data += String.fromCharCode(pos.x);
            data += String.fromCharCode(pos.y);
        }
        this.serverSendMessage(data);
    };
    ServerManager.prototype.GameOver = function () {
        console.log("GameOVer END TIME");
        clearInterval(this.updateInterval);
        var winnerID = this.getWinner();
        var winnerScore = this.playerServer[winnerID].score;
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_WINNER);
        data += String.fromCharCode(winnerID);
        data += String.fromCharCode(winnerScore);
        console.log("WINNER : " + winnerID);
        console.log("SCORE : " + winnerScore);
        // Send message COMMAND_SEND_WINNER
        this.serverSendMessage(data);
    };
    ServerManager.prototype.serverSendMessage = function (data) {
        // Send to all client
        // let command = data[0].charCodeAt(0);
        // // Make random latency for local player
        // for (let idx = 0; idx < this.MAX_PLAYER; idx++) {
        //    let player = this.listPlayer[idx];
        //    if(idx == 0 && this.latencyToggle.isChecked && command == this.COMMAND_SEND_UPDATE_PLAYERS_POS) // Make latency for Local Player Only when Toogle is checked
        //    {
        //         if (!this.isLatencies)
        //         {
        //             let latencies_time = Math.floor(Math.random() * 400);
        //             this.isLatencies = true;
        //             let latencies_timeout = setTimeout(function(){
        //                 player.getComponent("EasterEgg").onServerSendData(data);
        //                 this.isLatencies = false;
        //                 }.bind(this), latencies_time);
        //         }
        //         // else   
        //         // {
        //         //     // console.log("in Latencyyyyyyyyyyyyyyyyyyy");
        //         // } 
        //    }
        //    else
        //     player.getComponent("EasterEgg").onServerSendData(data);
        Server_1.Server.getInstance().receive(data);
        // }
    };
    // onClientSendData(data){
    //     console.log("Server Manager onClientsendData");
    //     let i = 0;
    //     // PlayerID at index 0
    //     let pID = data[i++].charCodeAt(0);
    //      // command at index 1
    //     let command = data[i++].charCodeAt(0);
    //     // console.log(this.playerPos);
    //     switch(command)
    //     {
    //         case this.COMMAND_SEND_PLAYER_POS:
    //             let pX = data[i++].charCodeAt(0) / 100;
    //             let pY = data[i++].charCodeAt(0) / 100;
    //             this.playerPos[pID] = cc.v2(pX, pY);
    //             break;
    //         case this.COMMAND_SEND_COLLECTED_EGG:
    //             let eID = data[i++].charCodeAt(0);
    //             // let eY = data[i++].charCodeAt(0);
    //             console.log("Server get info User "+pID+" collected "+eID);
    //             this.gainScore(pID,eID)
    //     }
    // }
    ServerManager.prototype.onSend = function (data) {
        // console.log("Game Send data for Server");
        var i = 0;
        // PlayerID at index 0
        var pID = data[i++].charCodeAt(0);
        // command at index 1
        var command = data[i++].charCodeAt(0);
        // console.log(this.playerPos);
        switch (command) {
            case this.COMMAND_SEND_PLAYER_POS:
                // let pos : cc.Vec2;
                var x = data[i++].charCodeAt(0) / 100;
                var y = data[i++].charCodeAt(0) / 100;
                var pos = cc.v2(x, y);
                this.playerServer[pID].position = pos;
                // console.log("Server get info User "+pID+" updated Pos "+pos);
                break;
            case this.COMMAND_SEND_COLLECTED_EGG:
                var eID = data[i++].charCodeAt(0);
                // let eY = data[i++].charCodeAt(0);
                // console.log("Server get info User "+pID+" collected "+eID);
                this.gainScore(pID, eID);
        }
    };
    ServerManager.prototype.onLoad = function () {
        // console.log("Loggggg");
        // console.log("Server Manager setCallback");
        // Server.getInstance().setCallback(this);
        Server_1.Server.getInstance().setCallbackSend(this.onSend.bind(this));
        this.eggSprite = [];
        this.playerSprite = [];
        this.listPlayer = [];
        this.listScore = [];
        this.eggsList = [];
        this.eggsPos = [];
        this.playerPos = [];
        this.playerServer = [];
        this.eggServer = [];
        this.initField();
        // this.resource = ResourceManager.getInstance();
        // ResourceManager.getInstance().init();
        // this.startGameInterval = setTimeout(function(){
        // //     // this.serverSendStartGame();
        //     this.loadPlayers();
        //     this.loadEggs();
        //     this.startGame();
        //  }.bind(this), 1000);
        this.gameState = this.LOADING_RESOURCE;
        // load resource and init player/egg
        // this.loadPlayers();
        // this.loadEggs();
        // this.startGame();
    };
    ServerManager.prototype.getPositionXY = function (col, row) {
        var pos = cc.v2(0, 0);
        pos.x = this.initPosX + (this.cell_w * col);
        pos.y = this.initPosY + (this.cell_w * row);
        return pos;
    };
    ServerManager.prototype.initField = function () {
        this.field = [];
        for (var i = 0; i < this.F_SIZE; i++) {
            this.field[i] = [];
            for (var j = 0; j < this.F_SIZE; j++) {
                this.field[i][j] = this.CELL_EMPTY;
            }
        }
    };
    ServerManager.prototype.gainScore = function (pID, eID) {
        var indexEgg = this.getIndexEgg(eID);
        // Check if that egg already collected by other Player
        if (indexEgg >= 0) {
            console.log("Collected Egg " + eID + "is OK");
            var player = this.playerServer[pID];
            player.score += 1;
            // this.listScore[ID] += 1;
            this.eggServer.splice(indexEgg, 1);
            // RESET this cell on field as EMPTY
            // this.field[posE.x][posE.y] = this.CELL_EMPTY; 
            // let egg = this.eggsList[indexEgg];
            // egg.destroy();
            // this.eggsList.splice(indexEgg, 1);
            this.serverSendUpdateScore();
            this.spawnEgg();
            console.log(this.playerServer[pID].score);
        }
    };
    ServerManager.prototype.serverSendUpdateScore = function () {
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_UPDATE_SCORE);
        for (var i = 0; i < this.playerServer.length; i++) {
            // let player = this.playerServer[i];
            data += String.fromCharCode(this.playerServer[i].score);
        }
        // Send client COMMAND_SEND_UPDATE_SCORE
        this.serverSendMessage(data);
    };
    ServerManager.prototype.serverSendUpdatePlayersPos = function () {
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_UPDATE_PLAYERS_POS);
        for (var i = 0; i < this.playerServer.length; i++) {
            var player = this.playerServer[i];
            // data += String.fromCharCode(player.id);
            var pos = player.position;
            // let rand = Math.random() * this.F_SIZE;
            // if(i != 0)
            //    pos = cc.v2(pos.x + rand, pos.y +rand);
            data += String.fromCharCode(pos.x * 100);
            data += String.fromCharCode(pos.y * 100);
            // console.log("Player ");
        }
        // Send client COMMAND_SEND_UPDATE_PLAYERS_POS
        this.serverSendMessage(data);
    };
    // WINNER info : ID and Score
    // getIndex(element, )
    ServerManager.prototype.getWinner = function () {
        var maxScore = Math.max.apply(Math, this.playerServer.map(function (o) { return o.score; }).concat([0]));
        // let index = this.playerServer.indexOf(Math.max(...this.listScore));
        //    console.log("Winer score "+this.playerServer[index].score);
        //    console.log("Winer Id "+this.playerServer[index].id);
        var index = this.playerServer.findIndex(function (o) { return o.score === maxScore; });
        // console.log("Winer Id "+index);
        // console.log("Winer Id maxScore "+maxScore);
        // console.log("Winer PlayerID "+(this.playerServer[index].id));
        return index;
    };
    ServerManager.prototype.spawnEgg = function () {
        if (this.eggServer.length == this.MAX_EGG)
            return;
        var egg = new (Egg_1.Egg);
        var OK = false;
        // console.log("EGgsprite "+this.eggSprite);
        while (!OK) {
            var ranCol = Math.floor(Math.random() * this.F_SIZE);
            var ranRow = Math.floor(Math.random() * this.F_SIZE);
            if (this.field[ranCol][ranRow] == this.CELL_EMPTY) {
                // egg.setPosition(this.getPositionXY(ranCol, ranRow));
                egg.position = cc.v2(ranCol, ranRow);
                // random color egg
                var ranSkinID = Math.floor(Math.random() * this.MAX_SKIN_EGG);
                egg.skinId = ranSkinID;
                egg.id = this.eggCount;
                // egg.getComponent(cc.Sprite).spriteFrame =this.eggSprite[ranEgg];
                // console.log("EGgsprite "+this.eggSprite[ranEgg]);
                // this.node.addChild(egg);
                // notice this field already have egg for the next check time
                this.field[ranCol][ranRow] = this.CELL_EGG;
                // this.eggsList.push(egg);
                // this.eggsPos.push(cc.v2(ranCol, ranRow));
                this.eggServer.push(egg);
                // this.eggsPos[0] = cc.v2(ranCol, ranRow);
                OK = true;
                this.eggCount += 1;
            }
        }
    };
    ServerManager.prototype.getIndexEgg = function (eID) {
        for (var i = 0; i < this.eggServer.length; i++) {
            var egg = this.eggServer[i];
            if (egg.id = eID)
                return i;
        }
        return -1;
    };
    ServerManager.prototype.initEggs = function () {
        var countEgg = 0;
        for (var i = 0; i < this.MAX_EGG; i++) {
            this.spawnEgg();
        }
        this.serverSendEggsPos();
    };
    ServerManager.prototype.initPlayers = function () {
        for (var i = 0; i < this.MAX_PLAYER; i++) {
            var OK = false;
            while (!OK) {
                var _player = new (Player_1.Player);
                var ranCol = Math.floor(Math.random() * this.F_SIZE);
                var ranRow = Math.floor(Math.random() * this.F_SIZE);
                if (this.field[ranCol][ranRow] == 0) // no egg/player in this cell
                 {
                    // // _player.
                    // if(i == 0) player.zIndex = 1;  // keep local player alway on top
                    // else player.zIndex = -2;
                    // // this.node.addChild(player);
                    // this.listPlayer[i] = player;
                    // // init user score
                    // this.listScore[i] = 0; 
                    // // notice this cell on field already have player for the next check time
                    this.field[ranCol][ranRow] = this.CELL_PLAYER;
                    _player.id = i;
                    _player.position = cc.v2(ranCol, ranRow);
                    _player.skinId = i;
                    _player.score = 0;
                    this.playerServer.push(_player);
                    OK = true;
                    // console.log("Server Init Player "+this.playerServer);
                }
            }
        }
    };
    ServerManager.prototype.sendInitPlayersPos = function () {
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_INIT_PLAYERS_POS);
        for (var i = 0; i < this.playerServer.length; i++) {
            // console.log("Server send Pos for Player "+i + "pos : "+this.playerPos[i]);
            // let player = this.playerServer[i];
            var pos = this.playerServer[i].position;
            data += String.fromCharCode(pos.x);
            data += String.fromCharCode(pos.y);
            console.log("Send innit player pos player " + i + " pos: ", pos);
        }
        this.serverSendMessage(data);
    };
    ServerManager.prototype.loadEggs = function () {
        // let resource = ResourceManager.getInstance();
        // this.eggSprite = resource.getSpriteList(resource.TYPE_EGG);
        this.initEggs();
    };
    ServerManager.prototype.loadPlayers = function () {
        var resource = ResourceManager_1.ResourceManager.getInstance();
        this.playerSprite = resource.getSpriteList(resource.TYPE_PLAYER);
        // console.log(this.playerSprite);
        this.initPlayers();
        this.sendMatchInfo();
        // this.sendInitPlayersPos();
        //delay send pos
        var delayInit = setTimeout(function () {
            this.sendInitPlayersPos();
        }.bind(this), this, .1000);
    };
    ServerManager.prototype.serverSendStartGame = function () {
        // TimeOut to GAME OVER 
        this.gameOverInterval = setTimeout(function () {
            this.GameOver();
        }.bind(this), this.MATCH_TIME);
        // Interval update, server send stage info
        this.updateInterval = setInterval(function () {
            // this.serverSendEggsPos();
            this.serverSendUpdatePlayersPos();
        }.bind(this), this.UPDATE_TIME);
        console.log("START GAME");
        // Send message COMMAND_SEND_START_GAME
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_START_GAME);
        data += String.fromCharCode(this.MATCH_TIME / 1000);
        this.serverSendMessage(data);
    };
    ServerManager.prototype.update = function (dt) {
        if (this.gameState == this.LOADING_RESOURCE && ResourceManager_1.ResourceManager.getInstance().isInited) {
            console.log("Finished Load Resource");
            this.loadPlayers();
            this.loadEggs();
            this.startGame();
            this.gameState = 3;
        }
        if (this.listPlayer.length < this.MAX_PLAYER)
            return;
        for (var i = 1; i < this.MAX_PLAYER; i++) {
            var player = this.listPlayer[i];
            if (this.showRemoteToggle.isChecked) {
                player.zIndex = 0;
            }
            else {
                player.zIndex = -2;
            }
        }
    };
    __decorate([
        property
    ], ServerManager.prototype, "MAX_PLAYER", void 0);
    __decorate([
        property
    ], ServerManager.prototype, "MAX_EGG", void 0);
    __decorate([
        property(cc.Prefab)
    ], ServerManager.prototype, "players", void 0);
    __decorate([
        property(cc.Prefab)
    ], ServerManager.prototype, "eggs", void 0);
    __decorate([
        property(cc.Prefab)
    ], ServerManager.prototype, "cell", void 0);
    __decorate([
        property(cc.Toggle)
    ], ServerManager.prototype, "latencyToggle", void 0);
    __decorate([
        property(cc.Toggle)
    ], ServerManager.prototype, "showRemoteToggle", void 0);
    __decorate([
        property
    ], ServerManager.prototype, "MATCH_TIME", void 0);
    ServerManager = __decorate([
        ccclass
    ], ServerManager);
    return ServerManager;
}(cc.Component));
exports.ServerManager = ServerManager;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ServerManager.js.map
        