(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/UI.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '9761eFrQF9AyqjNtgUxAVtd', 'UI', __filename);
// scripts/UI.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var UI = /** @class */ (function () {
    function UI() {
    }
    UI_1 = UI;
    ;
    UI.getInstance = function () {
        if (UI_1.instance == null) {
            UI_1.instance = new (UI_1);
        }
        return UI_1.instance;
    };
    UI.prototype.setUIManagerCallback = function (obj) {
        console.log("UI MANAGER SET CALLBACk");
        this.UIManagerCallback = obj;
    };
    UI.prototype.initCountdownTimer = function (time) {
        this.UIManagerCallback.initCountdownTimer(time);
    };
    UI.prototype.startCountdownTimer = function () {
        this.UIManagerCallback.startCountdownTimer();
    };
    UI.prototype.hideConnection = function () {
        this.UIManagerCallback.hideConnection();
    };
    UI.prototype.initLeaderBoard = function (num) {
        this.UIManagerCallback.initLeaderBoard(num);
    };
    UI.prototype.updateLeaderBoard = function (scores) {
        this.UIManagerCallback.updateLeaderBoard(scores);
    };
    var UI_1;
    UI = UI_1 = __decorate([
        ccclass
    ], UI);
    return UI;
}());
exports.UI = UI;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=UI.js.map
        