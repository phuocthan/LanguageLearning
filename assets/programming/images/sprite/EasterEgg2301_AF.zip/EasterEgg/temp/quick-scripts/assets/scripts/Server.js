(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Server.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '63b2aKwcgFH47zDAb7KwDxU', 'Server', __filename);
// scripts/Server.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Server = /** @class */ (function () {
    function Server() {
        this.Server = null;
    }
    Server_1 = Server;
    Server.getInstance = function () {
        if (Server_1._instance == null) {
            Server_1._instance = new (Server_1);
        }
        return Server_1._instance;
    };
    // setCallback(_class){
    //     console.log("Server SingleTon setCallback");
    //     console.log("Server SingleTon setCallback "+_class);
    //     this.classCallback = _class;
    // }
    // setClientCallback(_class){
    //     console.log("Client SingleTon setCallback");
    //     console.log("Client SingleTon setCallback "+_class);
    //     this.classClientCallback = _class;
    // }
    // onClientSendData(data){
    //     console.log("Server SingleTon onClientsendData");
    //     this.classCallback.onClientSendData(data);
    // }
    // onServerSendData(data){
    //     console.log("Server SingleTon onServerSendData");
    //     this.classClientCallback.onServerSendData(data);
    // }
    Server.prototype.setCallbackReceive = function (func) {
        this.callbackReceive = func;
    };
    Server.prototype.receive = function (data) {
        this.callbackReceive(data);
    };
    Server.prototype.setCallbackSend = function (func) {
        this.callbackSend = func;
    };
    Server.prototype.send = function (data) {
        this.callbackSend(data);
    };
    var Server_1;
    Server = Server_1 = __decorate([
        ccclass
    ], Server);
    return Server;
}());
exports.Server = Server;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Server.js.map
        