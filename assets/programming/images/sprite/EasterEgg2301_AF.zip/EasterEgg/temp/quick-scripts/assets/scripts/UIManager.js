(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/UIManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '60c84dJdkBLq5cOpAhz7aO3', 'UIManager', __filename);
// scripts/UIManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var UI_1 = require("./UI");
// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.timerLabel = null;
        _this.leaderboard = null;
        _this.connectionLayout = null;
        _this.lbItem = null;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    NewClass.prototype.onLoad = function () {
        UI_1.UI.getInstance().setUIManagerCallback(this);
        this.isGameStart = false;
        this.timerLabel.node.color = new cc.color(255, 255, 255, 0);
        this.lb_list = [];
    };
    NewClass.prototype.start = function () {
    };
    NewClass.prototype.initCountdownTimer = function (time) {
        this.matchTime = time;
        this.timerLabel.string = this.convertNumberToTimer(time);
    };
    NewClass.prototype.convertNumberToTimer = function (num) {
        var minute = Math.floor(num / 60);
        var second = Math.floor((num - (minute * 60)));
        var timer = this.formatTimer(minute, second);
        return timer;
    };
    NewClass.prototype.formatTimer = function (minute, second) {
        var tmpString = '';
        if (minute < 10)
            tmpString += '0' + minute;
        else
            tmpString += '' + minute;
        if (second < 10)
            tmpString += ':0' + second;
        else
            tmpString += ':' + second;
        return tmpString;
    };
    NewClass.prototype.startCountdownTimer = function (time) {
        this.isGameStart = true;
        this.endTime = Date.now() + this.matchTime * 1000;
    };
    NewClass.prototype.displayTimer = function () {
        // timer in seconds
        var timer = (this.endTime - Date.now()) / 1000;
        //set highlight color
        if (timer < 10) // alarm for user with Red color on timer
            this.timerLabel.node.color = new cc.color(255, 0, 0, 0);
        if (timer < 0) {
            return;
        }
        var minute = Math.floor(timer / 60);
        var second = Math.floor((timer - (minute * 60)));
        this.timerLabel.string = this.convertNumberToTimer(timer);
    };
    NewClass.prototype.hideConnection = function () {
        this.connectionLayout.node.active = false;
    };
    NewClass.prototype.initLeaderBoard = function (num) {
        var pos = 0;
        for (var i = 0; i < num; i++) {
            var lb = cc.instantiate(this.lbItem);
            lb.getComponent("Leaderboard_item").updateItem("Player " + i, 0);
            lb.setPosition(0, pos);
            pos -= 60;
            this.leaderboard.node.addChild(lb);
            this.lb_list.push(lb);
        }
    };
    NewClass.prototype.updateLeaderBoard = function (scores) {
        for (var i = 0; i < scores.length; i++) {
            this.lb_list[i].getComponent("Leaderboard_item").updateItem("Player " + i, scores[i]);
        }
    };
    NewClass.prototype.update = function (dt) {
        if (this.isGameStart)
            this.displayTimer();
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "timerLabel", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "leaderboard", void 0);
    __decorate([
        property(cc.Layout)
    ], NewClass.prototype, "connectionLayout", void 0);
    __decorate([
        property(cc.Prefab)
    ], NewClass.prototype, "lbItem", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=UIManager.js.map
        