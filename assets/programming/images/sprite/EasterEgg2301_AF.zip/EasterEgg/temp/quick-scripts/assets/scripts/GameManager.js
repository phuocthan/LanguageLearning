(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/GameManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3b20aPRiEZKzpnvkYFS3sCV', 'GameManager', __filename);
// scripts/GameManager.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ResourceManager_1 = require("./ResourceManager");
var Player_1 = require("./Player");
var Egg_1 = require("./Egg");
var Server_1 = require("./Server");
var UI_1 = require("./UI");
var GameManager = /** @class */ (function (_super) {
    __extends(GameManager, _super);
    function GameManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // Size of field, SIZE x SIZE
        _this.F_SIZE = 13;
        _this.cell = null;
        _this.remotePlayer = null;
        _this.playersPrefab = null;
        _this.eggsPrefab = null;
        _this.latencyCompensation = null;
        _this.NUM_PLAYER = 0;
        _this.initPosX = -515;
        _this.initPosY = -275;
        _this.cell_w = 50;
        //GAME STATE
        _this.gameState = 0;
        _this.LOADING_RESOURCE = 0;
        _this.INIT_PLAYER = 1;
        _this.GAME_UPDATE = 2;
        _this.GAME_STATE_RUNING = 3;
        _this.GAME_STATE_OVERED = 4;
        _this.CELL_EMPTY = 0;
        _this.COMMAND_SEND_JOIN_REQUEST = 0; // not deploy yet
        // MATCH_INFO : NUMPLAYER | MATCH_TIME | MAP COLUMNS | MAP ROWS
        _this.COMMAND_SEND_MATCH_INFO = 1;
        _this.COMMAND_SEND_START_GAME = 2;
        _this.COMMAND_SEND_WINNER = 3;
        _this.COMMAND_SEND_PLAYER_POS = 4;
        _this.COMMAND_SEND_COLLECTED_EGG = 5;
        _this.COMMAND_SEND_UPDATE_SCORE = 6;
        _this.COMMAND_SEND_INIT_PLAYERS_POS = 7;
        _this.COMMAND_SEND_EGGS_POS = 8;
        _this.COMMAND_SEND_UPDATE_PLAYERS_POS = 9;
        _this.MATCH_TIME = 0;
        _this.isInitedRemotePlayer = false;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    GameManager.prototype.initField = function () {
        this.field = [];
        for (var i = 0; i < this.F_SIZE; i++) {
            this.field[i] = [];
            for (var j = 0; j < this.F_SIZE; j++) {
                var newCel = cc.instantiate(this.cell);
                newCel.setPosition(this.getPositionXY(i, j));
                newCel.zIndex = -1;
                this.node.addChild(newCel);
                // mark this cell as EMPTY
                this.field[i][j] = this.CELL_EMPTY;
            }
        }
    };
    GameManager.prototype.initPlayer = function () {
        for (var i = 0; i < this.NUM_PLAYER; i++) {
            var nPlayer = cc.instantiate(this.playersPrefab);
            var _player = new (Player_1.Player);
            var OK = false;
            while (!OK) {
                nPlayer.getComponent(cc.Sprite).spriteFrame = this.playerSprites[i];
                nPlayer.getComponent("EasterEgg").playerID = i;
                nPlayer.getComponent("EasterEgg").isLocalPlayer = i == 0;
                // nPlayer.getComponent("EasterEgg").pFrame = i;
                nPlayer.setPosition(this.getPositionXY(i, i));
                if (i == 0)
                    nPlayer.zIndex = 1; // keep local player alway on top
                // else nPlayer.zIndex = -2;
                this.node.addChild(nPlayer);
                this.nodePlayerList.push(nPlayer);
                _player.id = i;
                _player.position = cc.v2(i, i);
                _player.skinId = i;
                _player.score = 0;
                this.playerClient.push(_player);
                OK = true;
            }
        }
        console.log("FINISHED INIT PLAYER");
    };
    GameManager.prototype.getPositionXY = function (col, row) {
        var pos = cc.v2(0, 0);
        pos.x = this.initPosX + (this.cell_w * col);
        pos.y = this.initPosY + (this.cell_w * row);
        return pos;
    };
    GameManager.prototype.onLoad = function () {
        this.playerClient = [];
        this.nodePlayerList = [];
        this.nodeRemotePlayerList = [];
        this.eggClient = [];
        this.gameState = this.LOADING_RESOURCE;
        ResourceManager_1.ResourceManager.getInstance().init();
        Server_1.Server.getInstance().setCallbackReceive(this.onReceive.bind(this));
        this.initField();
    };
    GameManager.prototype.initEgg = function () {
        for (var i = 0; i < this.eggClient.length; i++) {
            var egg = this.eggClient[i];
            var eggNode = cc.instantiate(this.eggsPrefab);
            eggNode.getComponent(cc.Sprite).spriteFrame = this.eggSprites[egg.skinId];
            eggNode.getComponent("EggManager").eID = i;
            var pos = egg.position;
            eggNode.setPosition(this.getPositionXY(pos.x, pos.y));
            // _player.
            // this.playerPos[i] = cc.v2(ranCol, ranRow);
            // if(i == 0) nPlayer.zIndex = 1;  // keep local player alway on top
            // else nPlayer.zIndex = -2;
            this.node.addChild(eggNode);
        }
    };
    GameManager.prototype.GameOver = function (winID, winScore) {
        // this.gamestate = this.GAME_STATE_OVERED;
        // if(this.isLocalPlayer)
        {
            cc.director.preloadScene('GameOver');
            // send info to winner scene
            var keyName = "name";
            var keyScore = "score";
            cc.sys.localStorage.setItem(keyName, winID);
            cc.sys.localStorage.setItem(keyScore, winScore);
            this.autoSaveInterval = setTimeout(function () {
                cc.director.loadScene('GameOver');
            }.bind(this), 1000);
        }
    };
    GameManager.prototype.onGameStart = function () {
        this.gameState = this.GAME_STATE_RUNING;
        //Start Countdown Timer for Client
        UI_1.UI.getInstance().startCountdownTimer();
        UI_1.UI.getInstance().hideConnection();
        // this.node.parent.parent.getChildByName("ConnectingPop").active = false;
        // this.node.parent.parent.getChildByName("CountdownTimer").getComponent("TimerCountDown").startCountdownTimer(this.MATCH_TIME/1000);
    };
    GameManager.prototype.initRemotePlayers = function () {
        // console.log("initRemotePlayers "+numRemotePlayer);
        for (var i = 0; i < this.NUM_PLAYER; i++) {
            var remote = cc.instantiate(this.remotePlayer);
            var player = this.playerClient[i];
            var pos = player.position;
            remote.getComponent(cc.Sprite).spriteFrame = this.playerSprites[player.skinId];
            // remote.getComponent(cc.Sprite).playerID =play
            remote.setPosition(this.getPositionXY(pos.x, pos.y));
            // console.log("Set spriteframe for remote player "+i);
            this.nodeRemotePlayerList.push(remote);
            // console.log("remotePlayerList "+ this.remotePlayerList);
            // console.log("remotePlayerPos "+ this.remotePlayerPos);
            // this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))   
            // this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))   
            this.node.parent.addChild(remote);
        }
        // console.log("initRemotePlayers "+this.nodeRemotePlayerList);
        // console.log("initRemotePlayers "+this.nodeRemotePlayerList);
        this.isInitedRemotePlayer = true;
    };
    GameManager.prototype.updateRemotePlayers = function () {
        // console.log("updateRemotePlayers "+this.nodeRemotePlayerList);
        // if(this.nodeRemotePlayerList == null || this.nodeRemotePlayerList.length != (this.MAX_PLAYER -1 ) )
        if (!this.isInitedRemotePlayer)
            return;
        // console.log("updateRemotePlayers "+this.nodeRemotePlayerList);
        // let isResolvedLatency = this.node.parent.getChildByName("Latency_Compensation").getComponent(cc.Toggle).isChecked;
        var isResolvedLatency = this.latencyCompensation.isChecked;
        for (var i = 0; i < this.NUM_PLAYER; i++) {
            if (!isResolvedLatency) {
                var player = this.playerClient[i];
                var pos = player.position;
                this.nodeRemotePlayerList[i].setPosition(this.getPositionXY(pos.x, pos.y));
            }
            // else{
            //     let currenPlayerPos = cc.v2(this.remotePlayerList[i].x, this.remotePlayerList[i].y);
            //     let remotePlayerPosXY = this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y);
            //     let lagDistance:cc.Vec2 = remotePlayerPosXY.sub(currenPlayerPos);
            //     // the largest dis we can apply
            //     if(lagDistance.mag() < 5 )
            //     {
            //         this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))
            //     }
            //     else
            //     {
            //         let x = lagDistance.normalize().x;
            //         let y =  lagDistance.normalize().y;
            //         let newMove = cc.v2(x,y).mul(1.6);
            //         this.remotePlayerList[i].setPosition(currenPlayerPos.x + newMove.x, currenPlayerPos.y + newMove.y));
            //     }
            // }
        }
    };
    GameManager.prototype.onReceive = function (data) {
        var i = 0;
        var command = data[i++].charCodeAt(0);
        switch (command) {
            case this.COMMAND_SEND_MATCH_INFO:
                console.log("GameManager  get COMMAND_SEND_MATCH_INFO");
                // this.MAX_PLAYER =  data[i++].charCodeAt(0);
                this.MATCH_TIME = data[i++].charCodeAt(0);
                console.log("GameManager  get COMMAND_SEND_MATCH_INFO MATCH_TIME " + this.MATCH_TIME);
                // this.F_COL =  data[i++].charCodeAt(0);
                // this.F_ROW =  data[i++].charCodeAt(0);
                // if(this.isLocalPlayer){
                //     this.initLeaderboard(this.MAX_PLAYER);
                // this.initRemotePlayers(this.MAX_PLAYER - 1);
                UI_1.UI.getInstance().initCountdownTimer(this.MATCH_TIME / 1000);
                UI_1.UI.getInstance().initLeaderBoard(this.NUM_PLAYER);
                // }
                break;
            case this.COMMAND_SEND_START_GAME:
                console.log("GameManager  get COMMAND_SEND_START_GAME");
                // let match_time = data[i++].charCodeAt(0);
                this.onGameStart();
                break;
            case this.COMMAND_SEND_WINNER:
                console.log("GameManager  get COMMAND_SEND_WINNER");
                var winID = data[i++].charCodeAt(0);
                var winScore = data[i++].charCodeAt(0);
                this.GameOver(winID, winScore);
                break;
            case this.COMMAND_SEND_UPDATE_SCORE:
                console.log("GameManager  get COMMAND_SEND_UPDATE_SCORE");
                var score = [];
                for (var idx = 0; idx < this.NUM_PLAYER; idx++) {
                    var scr = data[i++].charCodeAt(0);
                    score.push(scr);
                }
                console.log("Score " + score);
                //     this.scorelist = score;
                //     if(this.isLocalPlayer)
                UI_1.UI.getInstance().updateLeaderBoard(score);
                break;
            case this.COMMAND_SEND_INIT_PLAYERS_POS:
                console.log("GameManager  get COMMAND_SEND_INIT_PLAYERS_POS");
                for (var idx = 0; idx < this.NUM_PLAYER; idx++) {
                    var x = data[i++].charCodeAt(0);
                    var y = data[i++].charCodeAt(0);
                    var pos_1 = cc.v2(x, y);
                    this.playerClient[idx].position = pos_1;
                    this.nodePlayerList[idx].setPosition(this.getPositionXY(pos_1.x, pos_1.y));
                    console.log("GameManager  get COMMAND_SEND_INIT_PLAYERS_POS");
                }
                this.initRemotePlayers();
                break;
            case this.COMMAND_SEND_EGGS_POS:
                var numEgg = data[i++].charCodeAt(0);
                var ePos = [];
                // let egg = new (Egg);
                for (var idx = 0; idx < numEgg; idx++) {
                    var egg = new (Egg_1.Egg);
                    egg.id = data[i++].charCodeAt(0);
                    egg.skinId = data[i++].charCodeAt(0);
                    var x = data[i++].charCodeAt(0);
                    var y = data[i++].charCodeAt(0);
                    egg.position = cc.v2(x, y);
                    this.eggClient.push(egg);
                }
                // this.eggsPos = ePos;
                console.log("GameManager  get COMMAND_SEND_EGGS_POS");
                this.initEgg();
                break;
            case this.COMMAND_SEND_UPDATE_PLAYERS_POS:
                var pos = [];
                for (var idx = 0; idx < this.NUM_PLAYER; idx++) {
                    var x = data[i++].charCodeAt(0) / 100;
                    var y = data[i++].charCodeAt(0) / 100;
                    // if(idx == 0) // don't need to get local player pos
                    //     continue;
                    var p = cc.v2(x, y);
                    pos.push(p);
                    this.playerClient[idx].position = p;
                }
                this.updateRemotePlayers();
                // console.log("Pos "+pos);
                break;
        }
        //emd
    };
    GameManager.prototype.start = function () {
    };
    GameManager.prototype.update = function (dt) {
        // console.log("gameState " +this.gameState);
        switch (this.gameState) {
            case this.LOADING_RESOURCE:
                if (ResourceManager_1.ResourceManager.getInstance().isInited) {
                    // console.log("Game Manager LOADING_RESOURCE");
                    this.playerSprites = ResourceManager_1.ResourceManager.getInstance().getSpriteList(ResourceManager_1.ResourceManager.getInstance().TYPE_PLAYER);
                    this.eggSprites = ResourceManager_1.ResourceManager.getInstance().getSpriteList(ResourceManager_1.ResourceManager.getInstance().TYPE_EGG);
                    this.gameState = this.INIT_PLAYER;
                    console.log("LOADING_RESOURCE ");
                }
                break;
            case this.INIT_PLAYER:
                this.initPlayer();
                this.gameState = this.GAME_UPDATE;
                console.log("INIT_PLAYER ");
                break;
            case this.GAME_UPDATE:
                // console.log("GAME_UPDATE ");
                break;
        }
    };
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "cell", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "remotePlayer", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "playersPrefab", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "eggsPrefab", void 0);
    __decorate([
        property(cc.Toggle)
    ], GameManager.prototype, "latencyCompensation", void 0);
    __decorate([
        property
    ], GameManager.prototype, "NUM_PLAYER", void 0);
    GameManager = __decorate([
        ccclass
    ], GameManager);
    return GameManager;
}(cc.Component));
exports.default = GameManager;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameManager.js.map
        