(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/EasterEgg.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a5955kCFdJAFbLjydVhZUwt', 'EasterEgg', __filename);
// scripts/EasterEgg.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Server_1 = require("./Server");
// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.playerID = 0; // Local player, for remote player will be set > 0;
        _this.pName = null;
        _this.pFrame = 0;
        _this.MAX_EGG_SKINS = 8;
        _this.MAX_SKIN_PLAYER = 8;
        _this.remotePlayer = null;
        //Action Move direction
        _this.action_move = 0;
        _this.IDLE = 0;
        _this.MOVE_LEFT = 1;
        _this.MOVE_RIGHT = 2;
        _this.MOVE_UP = 3;
        _this.MOVE_DOWN = 4;
        _this.MOVE_COUNT = 5;
        // MAP_INFO
        _this.F_COL = 0;
        _this.F_ROW = 0;
        _this.MAX_PLAYER = 0;
        _this.MATCH_TIME = 0;
        //
        _this.isLocalPlayer = false;
        _this.initPosX = -515;
        _this.initPosY = -275;
        _this.cell_w = 50;
        _this.moveDistance = 100;
        //GAME STATE
        _this.GAME_STATE_WAITING = 0;
        _this.GAME_STATE_RUNING = 1;
        _this.GAME_STATE_OVERED = 2;
        _this.gamestate = 0;
        // COMMAND send between CLIENT and SERVER
        _this.COMMAND_SEND_JOIN_REQUEST = 0;
        // MATCH_INFO : NUMPLAYER | MATCH_TIME | MAP COLUMNS | MAP ROWS
        _this.COMMAND_SEND_MATCH_INFO = 1;
        _this.COMMAND_SEND_START_GAME = 2;
        _this.COMMAND_SEND_WINNER = 3;
        _this.COMMAND_SEND_PLAYER_POS = 4;
        _this.COMMAND_SEND_COLLECTED_EGG = 5;
        _this.COMMAND_SEND_UPDATE_SCORE = 6;
        _this.COMMAND_SEND_INIT_PLAYERS_POS = 7;
        _this.COMMAND_SEND_EGGS_POS = 8;
        _this.COMMAND_SEND_UPDATE_PLAYERS_POS = 9;
        _this.scaleRatioX = 0;
        _this.scaleRatioY = 0;
        _this.F_SIZE = 13;
        return _this;
    }
    // LEADERBOARD
    NewClass.prototype.onGameStart = function (time) {
        this.gamestate = this.GAME_STATE_RUNING;
        //Start Countdown Timer for Client
        // this.node.parent.parent.getChildByName("ConnectingPop").active = false;
        // this.node.parent.parent.getChildByName("CountdownTimer").getComponent("TimerCountDown").startCountdownTimer(this.MATCH_TIME/1000);
    };
    // GAME STATE END
    NewClass.prototype.getPositionXY = function (col, row) {
        var pos = cc.v2(0, 0);
        pos.x = this.initPosX + (this.cell_w * col);
        pos.y = this.initPosY + (this.cell_w * row);
        return pos;
    };
    NewClass.prototype.getPositionInField = function (x, y) {
        // col/row should be in range 0 :-> F_COL/F_ROW
        var col = (x - this.initPosX) / this.cell_w;
        var row = (y - this.initPosY) / this.cell_w;
        if (col < 0)
            col = 0;
        if (row < 0)
            row = 0;
        return (cc.v2(col, row));
    };
    NewClass.prototype.onKeyUp = function (event) {
        // Reset Action when key up ANY KEY
        this.action_move = this.IDLE;
    };
    NewClass.prototype.onKeyDown = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.left:
            case cc.macro.KEY.a:
                this.action_move = this.MOVE_LEFT;
                break;
            case cc.macro.KEY.right:
            case cc.macro.KEY.d:
                this.action_move = this.MOVE_RIGHT;
                break;
            case cc.macro.KEY.up:
            case cc.macro.KEY.w:
                this.action_move = this.MOVE_UP;
                break;
            case cc.macro.KEY.down:
            case cc.macro.KEY.s:
                this.action_move = this.MOVE_DOWN;
                break;
        }
        // console.log("action move for LocalPlayer "+ this.action_move);
    };
    NewClass.prototype.moveToEgg = function (pos) {
        // make a random, 
        var ranMove = [];
        var dis = 0.1; // make moving smooth
        if (this.myPos.x > pos.x + dis) {
            ranMove.push(this.MOVE_LEFT);
        }
        else if (this.myPos.x < pos.x - dis) {
            ranMove.push(this.MOVE_RIGHT);
        }
        if (this.myPos.y > pos.y + dis) {
            ranMove.push(this.MOVE_DOWN);
        }
        else if (this.myPos.y < pos.y - dis) {
            ranMove.push(this.MOVE_UP);
        }
        this.action_move = ranMove[Math.floor(Math.random() * ranMove.length)];
    };
    NewClass.prototype.moveActionToNearEgg = function () {
        if (1)
            return;
        // if(this.gamestate !=this.GAME_STATE_RUNING || this.eggsPos == null || this.eggsPos.length == 0)
        // {
        //     return;
        // }
        //find index of the egg nearest 
        var minIndex = 0;
        var minDist = this.myPos.sub(this.eggsPos[0]).mag();
        for (var i = 1; i < this.eggsPos.length; i++) {
            var distance = this.myPos.sub(this.eggsPos[i]).mag();
            if (minDist > distance) {
                minDist = distance;
                minIndex = i;
            }
        }
        // movo to it 
        this.moveToEgg(this.eggsPos[minIndex]);
    };
    NewClass.prototype.AI_Action = function () {
        //    this.moveActionToNearEgg();
        this.action_move = Math.floor(Math.random() * this.MOVE_COUNT);
    };
    NewClass.prototype.initRemotePlayers = function (numRemotePlayer) {
        // console.log("initRemotePlayers "+numRemotePlayer);
        for (var i = 0; i < numRemotePlayer; i++) {
            var remote = cc.instantiate(this.remotePlayer);
            remote.getComponent(cc.Sprite).spriteFrame = this.playerSprite[i + 1];
            // console.log("Set spriteframe for remote player "+i);
            this.remotePlayerList.push(remote);
            // console.log("remotePlayerList "+ this.remotePlayerList);
            // console.log("remotePlayerPos "+ this.remotePlayerPos);
            this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y));
            // this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y))   
            this.node.parent.addChild(remote);
        }
    };
    NewClass.prototype.clientSendCollectedEgg = function (eID) {
        // let pos = this.getPositionInField(posEggCollected.x, posEggCollected.y)
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_COLLECTED_EGG);
        // data += String.fromCharCode(this.playerID);
        data += String.fromCharCode(eID);
        console.log("Player ID " + this.playerID + "send Collected " + eID);
        this.clientSendMessage(data);
    };
    NewClass.prototype.clientUpdateRemotePlayerPos = function () {
        if (this.remotePlayerList == null || this.remotePlayerList.length != (this.MAX_PLAYER - 1) || this.remotePlayerPos.length != (this.MAX_PLAYER - 1))
            return;
        // let isResolvedLatency = this.node.parent.getChildByName("Latency_Compensation").getComponent(cc.Toggle).isChecked;
        var isResolvedLatency = this.node.parent.parent.getChildByName("Latency_Compensation").getComponent(cc.Toggle).isChecked;
        for (var i = 0; i < this.MAX_PLAYER - 1; i++) {
            if (!isResolvedLatency) {
                this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y));
            }
            else {
                var currenPlayerPos = cc.v2(this.remotePlayerList[i].x, this.remotePlayerList[i].y);
                var remotePlayerPosXY = this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y);
                var lagDistance = remotePlayerPosXY.sub(currenPlayerPos);
                // the largest dis we can apply
                if (lagDistance.mag() < 5) {
                    this.remotePlayerList[i].setPosition(this.getPositionXY(this.remotePlayerPos[i].x, this.remotePlayerPos[i].y));
                }
                else {
                    var x = lagDistance.normalize().x;
                    var y = lagDistance.normalize().y;
                    var newMove = cc.v2(x, y).mul(1.6);
                    this.remotePlayerList[i].setPosition(currenPlayerPos.x + newMove.x, currenPlayerPos.y + newMove.y);
                    ;
                }
            }
        }
    };
    NewClass.prototype.clientSendPos = function () {
        var data = "";
        data += String.fromCharCode(this.COMMAND_SEND_PLAYER_POS);
        data += String.fromCharCode(this.myPos.x * 100);
        data += String.fromCharCode(this.myPos.y * 100);
        this.clientSendMessage(data);
    };
    NewClass.prototype.clientSendMessage = function (data) {
        // if (1) return;
        var newData = "";
        // Insert PlayerID at index 0
        newData += String.fromCharCode(this.playerID);
        newData += data;
        Server_1.Server.getInstance().send(newData);
    };
    // END OF COMUNICATION
    NewClass.prototype.start = function () {
    };
    NewClass.prototype.onLoad = function () {
        this.playerSprite = [];
        this.remotePlayerList = [];
        // this.gamestate = this.GAME_STATE_WAITING;        
        console.log("Player ID : " + this.playerID + " is Local Player :", this.isLocalPlayer);
        if (this.isLocalPlayer) {
            // this.loadPlayers();
            // this.playerSprite = ResourceManager.getInstance().getSpriteList(ResourceManager.getInstance().TYPE_PLAYER);
            cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
            cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        }
        else {
            this.pName.string = "p" + this.playerID;
        }
    };
    NewClass.prototype.update = function (dt) {
        // Update and send new Pos to server
        if (!this.isLocalPlayer) {
            this.AI_Action();
        }
        else {
            this.clientUpdateRemotePlayerPos();
        }
        // if( this.action_move == this.IDLE) 
        // if(this.gamestate != this.GAME_STATE_RUNING || this.action_move == this.IDLE) 
        // return;
        // console.log("Update "+this.action_move);
        var currentPos = this.getPositionInField(this.node.x, this.node.y);
        // if (this.isLocalPlayer)
        //     console.log(currentPos);
        if (this.action_move == this.MOVE_LEFT && currentPos.x > 0) {
            // console.log("Update MOVE LEFT");
            this.node.x -= this.moveDistance * dt;
        }
        if (this.action_move == this.MOVE_RIGHT && currentPos.x < this.F_SIZE - 1) {
            this.node.x += this.moveDistance * dt;
            // console.log("Update MOVE MOVE_RIGHT");
        }
        if (this.action_move == this.MOVE_UP && currentPos.y < this.F_SIZE - 1) {
            this.node.y += this.moveDistance * dt;
            // console.log("Update MOVE MOVE_UP");
        }
        if (this.action_move == this.MOVE_DOWN && currentPos.y > 0) {
            this.node.y -= this.moveDistance * dt;
            // console.log("Update MOVE MOVE_DOWN");
        }
        this.myPos = this.getPositionInField(this.node.x, this.node.y);
        this.clientSendPos();
    };
    __decorate([
        property
    ], NewClass.prototype, "playerID", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "pName", void 0);
    __decorate([
        property(cc.Prefab)
    ], NewClass.prototype, "remotePlayer", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=EasterEgg.js.map
        